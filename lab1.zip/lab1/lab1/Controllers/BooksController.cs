﻿using lab1.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;

namespace lab1.Controllers
{
    /// <summary>
    /// API quản lý sách
    /// </summary>
    [Route("api/[controller]")]
    [ApiController]
    public class BooksController : ControllerBase
    {
        // Dữ liệu mẫu (in-memory)
        private static List<Book> _books = new List<Book>
        {
            new Book { Id = 1, Name = "Conan", Price = 35000 },
            new Book { Id = 2, Name = "Doraemon", Price = 26000 }
        };

        /// <summary>
        /// Lấy danh sách 
        /// </summary>
        [HttpGet]
        public ActionResult<IEnumerable<Book>> GetAll()
        {
            return Ok(_books);
        }

        /// <summary>
        /// Lấy thông tin sách theo ID
        /// </summary>
        /// <param name="id">ID sách</param>
        [HttpGet("{id}")]
        public ActionResult<Book> GetById(int id)
        {
            var book = _books.FirstOrDefault(b => b.Id == id);
            if (book == null)
                return NotFound();
            return Ok(book);
        }

        /// <summary>
        /// Thêm sách mới
        /// </summary>
        /// <param name="book">Thông tin sách</param>
        [HttpPost]
        public ActionResult<Book> Create(Book book)
        {
            book.Id = _books.Max(b => b.Id) + 1;
            _books.Add(book);
            return CreatedAtAction(nameof(GetById), new { id = book.Id }, book);
        }

        /// <summary>
        /// Cập nhật sách theo ID
        /// </summary>
        /// <param name="id">ID sách</param>
        /// <param name="updatedBook">Thông tin mới</param>
        [HttpPut("{id}")]
        public IActionResult Update(int id, Book updatedBook)
        {
            var existing = _books.FirstOrDefault(b => b.Id == id);
            if (existing == null)
                return NotFound();

            existing.Name = updatedBook.Name;
            existing.Price = updatedBook.Price;

            return NoContent();
        }

        /// <summary>
        /// Xoá sách theo ID
        /// </summary>
        /// <param name="id">ID sách</param>
        [HttpDelete("{id}")]
        public IActionResult Delete(int id)
        {
            var book = _books.FirstOrDefault(b => b.Id == id);
            if (book == null)
                return NotFound();

            _books.Remove(book);
            return NoContent();
        }
    }
}
