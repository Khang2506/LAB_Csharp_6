﻿namespace lab1.Models
{
    /// <summary>
    /// Thông tin sản phẩm
    /// </summary>
    public class Book
    {
        /// <summary>
        /// ID của sản phẩm
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Tên sản phẩm
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// Giá sản phẩm
        /// </summary>
        public decimal Price { get; set; }
    }
}